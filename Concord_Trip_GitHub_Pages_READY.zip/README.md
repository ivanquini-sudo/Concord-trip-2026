# Concord Trip 2026

Family itinerary website for October 3–7, 2026.

## Publish with GitHub Pages
1. Upload all files in this folder to the root of the `main` branch.
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select **main** and **/(root)**, then save.
5. After GitHub finishes publishing, the site will be available at:
   `https://ivanquini-sudo.github.io/Concord-trip-2026/`

The site intentionally excludes Airbnb entry codes and exact private lodging addresses.
